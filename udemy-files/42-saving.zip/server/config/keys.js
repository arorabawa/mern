module.exports = {
  googleClientID: '',
  googleClientSecret: '',
  mongoURI: '',
};
